require 'colorize'
require './Engine'


TeGui.clear

TeGui.frame(11,11)

TeGui.text("s","right","down","")

TeGui.print


#words = String.colors { |x| x.to_s } 

=begin
arr = Array.new(20, " ")

i = 0

arr.fill("o", 0..5)

5.times do

arr.fill("a", 0..i)
i += 1

end

print arr

=end

#4x4

#puts "\033[31m RED \033[0m DEFAULT"

#var = ":blue"

#puts "[0;31;49m This is blue 0m"

#[0;39m



#puts var

