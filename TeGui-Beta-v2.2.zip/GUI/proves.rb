require './Engine.rb'

TeGui.clear

TeGui.frame(100,25)

TeGui.frameinframe(1,25,1,100)

TeGui.ascii("ahegao.ascii","middle","up","red")

TeGui.text("s","left","middle","")

TeGui.print
